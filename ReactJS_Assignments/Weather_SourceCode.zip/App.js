import logo from './logo.svg';
import './App.css';
import Weather from './Components/Assignment4/Weather';

function App() {

  return (
    <div>
     <Weather/>    
    </div>
  );
}

export default App;
