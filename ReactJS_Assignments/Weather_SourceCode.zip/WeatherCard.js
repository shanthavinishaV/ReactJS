//Weather Component with State Management:
import React, { useState } from "react";
import './weather.css';
function WeatherCard(props) {


    return (

        <div>
            <table>
                <tr>
                    <td>{props.day}</td>
                    <td>{props.condition}</td>
                    <td>{props.temperature}</td>
                </tr>
            </table>
        </div>
    );

}

export default WeatherCard;